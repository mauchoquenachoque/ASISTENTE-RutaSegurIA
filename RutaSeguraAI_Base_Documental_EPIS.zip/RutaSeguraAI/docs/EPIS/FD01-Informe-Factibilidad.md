# FD01 — Informe de Factibilidad

> **Proyecto:** Ruta Segura AI PRO  
> **Institución:** Universidad Privada de Tacna — EPIS  
> **Estado:** Borrador técnico inicial; no es documento aprobado  
> **Versión:** 0.1.0 | **Fecha:** 2026-11-20  
> **Curso / docente / integrantes:** [PENDIENTE DE COMPLETAR]  
> **Normativa:** Secciones adaptadas de los archivos FD01–FD06 proporcionados.  
> **Control documental:** Ver `docs/EPIS/00-GOBERNANZA-Y-TRAZABILIDAD.md`.

## Control de versiones

| Versión | Fecha | Autor | Revisó | Aprobó | Cambio |
|---|---|---|---|---|---|
| 0.1.0 | 2026-11-20 | [Por definir] | Pendiente | Pendiente | Base documental inicial |

## 1. Descripción del proyecto

Nombre: Ruta Segura AI PRO. Aplicación Android de percepción visual, lectura OCR, navegación orientativa y reportes de accesibilidad. Duración: [POR DEFINIR]. Objetivo: brindar información complementaria de movilidad y lectura a personas con discapacidad visual usando un teléfono Android.

## 1.4 Objetivos

Objetivo general: implementar y evaluar un prototipo accesible de asistencia contextual móvil, con funciones esenciales offline y servicios colaborativos online. Específicos: integrar detección de objetos local, OCR, voz, localización, cartografía, reportes y sincronización; realizar pruebas de usabilidad y rendimiento.

## 2. Riesgos

R-01 falsos negativos de detección (alto); R-02 datos de rutas incompletos (alto); R-03 pérdida de red (medio); R-04 consumo energético (medio); R-05 acceso no autorizado a ubicación (alto); R-06 licencias/cuotas de mapas (medio). Mitigación: avisos de limitaciones, evaluación controlada, modo offline-first, consentimiento, validación de proveedores.

## 3. Análisis de la situación actual

Problema: las soluciones de orientación y lectura no siempre integran percepción, reportes de barreras y continuidad sin internet. Levantamiento empírico pendiente: entrevistas accesibles y pruebas supervisadas. Hardware: Android con cámara, GPS y altavoz; sensores según equipo. Software: Kotlin y librerías verificadas.

## 4. Estudio de factibilidad

4.1 Técnica: factible como prototipo condicionado a rendimiento del móvil y datasets. 4.2 Económica: librerías libres, pero hosting, internet, tiempo y equipos tienen costo económico aunque no haya pagos por licencias. 4.3 Operativa: requiere pruebas con usuarios. 4.4 Legal: privacidad de ubicación e imágenes, licencias de datos y apps. 4.5 Social: accesibilidad y co-diseño. 4.6 Ambiental: uso eficiente de batería y equipamiento existente.

## 5. Análisis financiero

Completar tablas de costos generales, operativos, ambiente, personal y totales. No inventar costos ni ingresos. B/C, VAN y TIR: calcular solo si se dispone de supuestos financieros sustentados; de lo contrario, explicar no aplicabilidad y presentar costo total de prototipo y escenarios.

## 6. Conclusiones

[PENDIENTE DE RESULTADOS Y VALIDACIÓN]. No declarar factibilidad confirmada sin pruebas y costos registrados.

---

**Nota de conformidad:** El archivo oficial editable en Word deberá conservar portada, logos, tablas e índices exigidos por la plantilla docente. Este Markdown es la fuente de trabajo coordinada, no reemplaza la entrega DOCX.
