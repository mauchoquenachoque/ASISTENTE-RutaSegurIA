# FD02 — Documento de Visión

> **Proyecto:** Ruta Segura AI PRO  
> **Institución:** Universidad Privada de Tacna — EPIS  
> **Estado:** Borrador técnico inicial; no es documento aprobado  
> **Versión:** 0.1.0 | **Fecha:** 2026-11-20  
> **Curso / docente / integrantes:** [PENDIENTE DE COMPLETAR]  
> **Normativa:** Secciones adaptadas de los archivos FD01–FD06 proporcionados.  
> **Control documental:** Ver `docs/EPIS/00-GOBERNANZA-Y-TRAZABILIDAD.md`.

## Control de versiones

| Versión | Fecha | Autor | Revisó | Aprobó | Cambio |
|---|---|---|---|---|---|
| 0.1.0 | 2026-11-20 | [Por definir] | Pendiente | Pendiente | Base documental inicial |

## 1. Introducción

1.1 Propósito: definir usuarios, problema, alcance y características de Ruta Segura AI. 1.2 Alcance: prototipo de apoyo informativo; no sustituye técnicas de movilidad. 1.3 Siglas: GPS, OCR, TTS, IA, SRS, SAD, MVP. 1.4 Referencias: FD01/FD03/FD04 y documentación Android. 1.5 Visión general.

## 2. Posicionamiento

2.1 Oportunidad: integrar detección local, lectura, mapas y avisos comunitarios. 2.2 Problema: dificultad de acceso rápido a información de entorno, letreros y barreras reportadas; necesidad de datos reales por validar.

## 3. Interesados y usuarios

3.1 Interesados: usuarios con discapacidad visual, acompañantes/contactos de confianza, equipo de desarrollo, evaluadores y potenciales organizaciones. 3.2 Usuarios: usuario principal; moderador de reportes (solo si se implementa). 3.3 Entorno: Android, interior/exterior, conectividad variable. 3.4–3.6 Perfiles y necesidades: accesibilidad, claridad de alertas, privacidad, continuidad offline y control de datos.

## 4. Vista general del producto

4.1 App modular offline-first. 4.2 Capacidades: visión local RF-01, OCR RF-02, voz RF-03, GPS RF-04, rutas RF-05, reportes RF-06, SOS RF-07, sincronización RF-08, configuración RF-09. 4.3 Dependencias: dispositivos Android, modelos y cartografía con licencia adecuada. 4.4 Costos por estimar. 4.5 Licencias e instalación por validar.

## 5. Características del producto

Detección de categorías verificadas; lectura por voz; gestión accesible de destino y reportes; cola de sincronización; emergencias mediante canales disponibles. Cada función se vincula con RF, casos de uso y pruebas.

## 6. Restricciones

Sin sensores externos obligatorios; offline para IA/OCR/datos locales; red necesaria para actualizar rutas y compartir reportes; no garantizar caminos seguros ni distancias exactas por bounding boxes.

## 7. Rangos de calidad

Objetivos de accesibilidad, exactitud, latencia y autonomía se definirán en FD03 y se medirán en dispositivo físico; no prometer cifras aún.

## 8. Precedencia y prioridad

MVP: RF-01, RF-02, RF-03, RF-09; después RF-04, RF-05, RF-07; posteriormente RF-06 y RF-08.

## 9. Otros requerimientos del producto

Cumplimiento de privacidad, licencia de mapas/modelos, requisitos de comunicación, calidad y seguridad. Referenciar evidencia y fecha de comprobación.

---

**Nota de conformidad:** El archivo oficial editable en Word deberá conservar portada, logos, tablas e índices exigidos por la plantilla docente. Este Markdown es la fuente de trabajo coordinada, no reemplaza la entrega DOCX.
