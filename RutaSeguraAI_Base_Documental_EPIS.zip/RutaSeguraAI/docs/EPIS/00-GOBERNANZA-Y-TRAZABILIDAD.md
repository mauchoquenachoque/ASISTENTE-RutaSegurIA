# Gobierno documental y trazabilidad — Ruta Segura AI PRO

## Regla rectora
Los documentos FD01–FD06 y el código deben cambiar juntos. Los Word cargados son las **plantillas normativas**; el FD03 cargado está desarrollado para otro proyecto (Monitor de Métricas BI), por lo que **solo su estructura metodológica** sirve de referencia. No copiar sus autores, datos, mediciones ni conclusiones.

## Documentos y relación normativa
| Documento | Rol | Secciones obligatorias principales |
|---|---|---|
| FD01 Factibilidad | Viabilidad | Descripción, riesgos, situación actual, factibilidad técnica/económica/operativa/legal/social/ambiental, financiero, conclusiones |
| FD02 Visión | Usuarios y producto | Introducción, posicionamiento, interesados/usuarios, vista del producto, características, restricciones, calidad, prioridades |
| FD03 SRS | Contrato de requisitos | Empresa/organización, visionamiento, procesos, RF/RNF, reglas, perfiles, UML conceptual/lógico |
| FD04 SAD | Diseño trazable | Introducción, prioridades, vistas 4+1, diagramas, escenarios de calidad |
| FD05 Final | Evidencia consolidada | Antecedentes, problema, objetivos, marco teórico, solución, cronograma, presupuesto, conclusiones, anexos FD01–FD04 |
| FD06 Propuesta | Plan y compromiso | Resumen ejecutivo, propuesta narrativa, actores, monitoreo, cronograma, hitos, presupuesto, factibilidad |

## Secuencia de dependencia (no orden numérico)
FD06 propuesta ↔ FD01 factibilidad ↔ FD02 visión → FD03 SRS → FD04 arquitectura → código/pruebas → FD05 informe final. Los cambios se propagan en ambas direcciones.

## Matriz de trazabilidad inicial
| RF | Función | Caso de uso | Módulo Android | Prueba | Entrega |
|---|---|---|---|---|---|
| RF-01 | Visión artificial local | CU-01 | vision | TC-01 | MVP |
| RF-02 | Lectura OCR | CU-02 | ocr | TC-02 | MVP |
| RF-03 | Alertas TTS/vibración | CU-03 | audio | TC-03 | MVP |
| RF-04 | Ubicación GPS | CU-04 | location | TC-04 | Fase 2 |
| RF-05 | Navegación y mapas | CU-05 | navigation | TC-05 | Fase 2 |
| RF-06 | Reportes de accesibilidad | CU-06 | reports | TC-06 | Fase 3 |
| RF-07 | SOS y contacto | CU-07 | emergency | TC-07 | Fase 2 |
| RF-08 | Sincronización offline-first | CU-08 | sync | TC-08 | Fase 3 |
| RF-09 | Preferencias accesibles | CU-09 | settings | TC-09 | MVP |
| RF-10 | Historial | CU-10 | history | TC-10 | Fase 3 |

## Control de cambios obligatorio
1. Abrir incidencia o propuesta de cambio con causa y alcance.
2. Actualizar FD02 si cambia la visión o el alcance.
3. Actualizar FD03 primero cuando cambia una función o criterio de aceptación.
4. Actualizar FD04 si impacta componentes, datos, despliegue, procesos o calidad.
5. Implementar el código con referencia al RF y al caso de prueba.
6. Ejecutar pruebas y registrar evidencias reales.
7. Revisar impactos en riesgos/costos (FD01), cronograma/hitos (FD06) y resultados (FD05).
8. Incrementar versiones de documentos afectados y registrar autor, fecha, revisión y aprobación (sin inventar firmas).

## Definición de terminado (DoD)
Una función solo está terminada si tiene RF aprobado, escenario CU, diseño vigente, código integrado, prueba repetible, evidencia verificable, comportamiento offline documentado y accesibilidad evaluada.

## Control de fuentes gratuitas
Gratis no significa ilimitado ni sin condiciones. No descargar masivamente teselas de `tile.openstreetmap.org`; Nominatim público no debe usarse para autocompletado intensivo; confirmar términos y cuotas de proveedores de rutas. Preferir bibliotecas libres y cartografía offline con distribución permitida. No introducir claves secretas en el APK.

## Riesgos de seguridad del producto
La app no promete caminos libres de obstáculos ni distancia métrica basada solo en bounding box. No reemplaza bastón blanco o formación de orientación. Las pruebas iniciales serán supervisadas y en escenarios controlados.

## Datos pendientes para completar portada y aprobaciones
Curso, docente, equipo e identificadores universitarios, organización/cliente real, versión y firmas, alcance aprobado, cronograma, presupuesto, hardware de pruebas, evidencias con consentimiento, resultados experimentales.
