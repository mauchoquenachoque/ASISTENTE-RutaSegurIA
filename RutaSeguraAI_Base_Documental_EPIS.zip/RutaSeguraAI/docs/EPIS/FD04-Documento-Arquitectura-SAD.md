# FD04 — Documento de Arquitectura de Software (SAD)

> **Proyecto:** Ruta Segura AI PRO  
> **Institución:** Universidad Privada de Tacna — EPIS  
> **Estado:** Borrador técnico inicial; no es documento aprobado  
> **Versión:** 0.1.0 | **Fecha:** 2026-11-20  
> **Curso / docente / integrantes:** [PENDIENTE DE COMPLETAR]  
> **Normativa:** Secciones adaptadas de los archivos FD01–FD06 proporcionados.  
> **Control documental:** Ver `docs/EPIS/00-GOBERNANZA-Y-TRAZABILIDAD.md`.

## Control de versiones

| Versión | Fecha | Autor | Revisó | Aprobó | Cambio |
|---|---|---|---|---|---|
| 0.1.0 | 2026-11-20 | [Por definir] | Pendiente | Pendiente | Base documental inicial |

## 1. Introducción

1.1 Propósito: describir arquitectura 4+1 para Ruta Segura AI. 1.2 Alcance. 1.3 Glosario. 1.4 Organización.

## 2. Objetivos y restricciones arquitectónicas

Priorizar RF-01..RF-10 y RNF-01..RNF-07 del FD03. Decisiones: procesamiento IA local, diseño offline-first, mapa descargable con licencia, mínima exposición de ubicación, degradación gradual sin red.

## 3.1 Vista de casos de uso

Actores: persona usuaria y contacto de confianza (externo); opcional servicio colaborativo. Casos CU-01 visión, CU-02 OCR, CU-03 GPS, CU-04 rutas, CU-05 reporte, CU-06 SOS, CU-07 ajustes, CU-08 sincronización. Adjuntar narrativas y diagramas.

## 3.2 Vista lógica

Subsistemas/paquetes: presentation, domain, data, camera, vision, ocr, audio, navigation, reports, emergency, sync. Diagramas requeridos en plantilla: paquetes, secuencia, colaboración, objetos, clases y BD.

## 3.3 Vista de implementación

Android Kotlin/Compose, ViewModels, use cases, repositories, Room, CameraX, TFLite/LiteRT, ML Kit, WorkManager, cliente HTTP. Backend colaborativo opcional de código abierto; separar contrato API y proveedor elegido.

## 3.4 Vista de procesos

Procesos: captura de cámara, inferencia, decisión de alerta, TTS; obtención de ruta; cola persistente y reintentos; suspensión por ciclo de vida. Diagramas de actividad.

## 3.5 Vista de despliegue

Nodo teléfono Android: aplicación, base local, modelos y mapas cacheados. Nodo servidor opcional: API y DB para reportes compartidos; servicios de rutas online. Diagramar dependencia de red, ausencia de red y datos sensibles.

## 4. Atributos de calidad

Escenarios medibles de funcionalidad, usabilidad, confiabilidad, rendimiento y mantenibilidad. Registrar estímulo, entorno, respuesta y métrica. No declarar cumplimiento sin evidencia.

---

**Nota de conformidad:** El archivo oficial editable en Word deberá conservar portada, logos, tablas e índices exigidos por la plantilla docente. Este Markdown es la fuente de trabajo coordinada, no reemplaza la entrega DOCX.
