# FD05 — Informe de Proyecto Final

> **Proyecto:** Ruta Segura AI PRO  
> **Institución:** Universidad Privada de Tacna — EPIS  
> **Estado:** Borrador técnico inicial; no es documento aprobado  
> **Versión:** 0.1.0 | **Fecha:** 2026-11-20  
> **Curso / docente / integrantes:** [PENDIENTE DE COMPLETAR]  
> **Normativa:** Secciones adaptadas de los archivos FD01–FD06 proporcionados.  
> **Control documental:** Ver `docs/EPIS/00-GOBERNANZA-Y-TRAZABILIDAD.md`.

## Control de versiones

| Versión | Fecha | Autor | Revisó | Aprobó | Cambio |
|---|---|---|---|---|---|
| 0.1.0 | 2026-11-20 | [Por definir] | Pendiente | Pendiente | Base documental inicial |

## 1. Antecedentes

Revisión de tecnologías existentes y evidencia sobre accesibilidad. [PENDIENTE REVISIÓN BIBLIOGRÁFICA].

## 2. Planteamiento del problema

2.a Problema; 2.b Justificación; 2.c Alcance — mantener exactamente los límites FD02/FD03.

## 3. Objetivos

Reutilizar objetivos aprobados en FD01/FD02, con resultados medidos.

## 4. Marco teórico

Visión por computador, OCR, TTS, GPS, navegación, accesibilidad, offline-first, privacidad. Citar documentación oficial y fuentes académicas.

## 5. Desarrollo de la solución

a) factibilidad: técnico, económico, operativo, social, legal, ambiental (FD01); b) tecnologías reales instaladas; c) metodología y anexos: FD02 Visión, FD03 SRS, FD04 SAD. Incluir pruebas, capturas y trazabilidad.

## 6. Cronograma

Consolidar fechas reales y cambios respecto de FD06.

## 7. Presupuesto

Consolidar costos reales y supuestos documentados desde FD01/FD06.

## 8. Conclusiones

Solo conclusiones avaladas por mediciones, pruebas y validación.

## Recomendaciones

Mejoras, riesgos abiertos, necesidad de pruebas con usuarios y límites del prototipo.

## Bibliografía y anexos

Anexo 01 FD01, Anexo 02 FD02, Anexo 03 FD03, Anexo 04 FD04, Anexo 05 manuales y otros documentos; enlaces a commits y evidencias.

---

**Nota de conformidad:** El archivo oficial editable en Word deberá conservar portada, logos, tablas e índices exigidos por la plantilla docente. Este Markdown es la fuente de trabajo coordinada, no reemplaza la entrega DOCX.
