# FD06 — Propuesta del Proyecto

> **Proyecto:** Ruta Segura AI PRO  
> **Institución:** Universidad Privada de Tacna — EPIS  
> **Estado:** Borrador técnico inicial; no es documento aprobado  
> **Versión:** 0.1.0 | **Fecha:** 2026-11-20  
> **Curso / docente / integrantes:** [PENDIENTE DE COMPLETAR]  
> **Normativa:** Secciones adaptadas de los archivos FD01–FD06 proporcionados.  
> **Control documental:** Ver `docs/EPIS/00-GOBERNANZA-Y-TRAZABILIDAD.md`.

## Control de versiones

| Versión | Fecha | Autor | Revisó | Aprobó | Cambio |
|---|---|---|---|---|---|
| 0.1.0 | 2026-11-20 | [Por definir] | Pendiente | Pendiente | Base documental inicial |

## Resumen ejecutivo

Nombre: Ruta Segura AI PRO. Lugar: Tacna – Perú. Propósito: apoyo informativo accesible mediante cámara, voz, GPS y reportes, disponible de forma degradada sin internet. Beneficiarios: personas con discapacidad visual. Inversión/duración: [POR ESTIMAR].

## I.1 Planteamiento del problema

Dificultades de acceder oportunamente a información visual y reportes de barreras. Validar alcance y magnitud mediante levantamiento de información.

## I.2 Justificación

Impacto social, integración de servicios Android, innovación incremental y datos comunitarios verificados.

## I.3 Objetivo general

Desarrollar y evaluar un prototipo Android híbrido y accesible de asistencia contextual.

## I.4 Beneficios

Lectura y avisos accesibles; registro de reportes; operación básica offline. Beneficios potenciales, sujetos a prueba.

## I.5 Alcance

Incluye IA local, OCR, TTS, GPS, rutas descargables, reportes pendientes, SOS asistido. Excluye guía autónoma garantizada y detección universal de peligros.

## I.6 Requerimientos del sistema

Referenciar RF-01..RF-10 y RNF-01..RNF-07 de FD03, sin duplicar definiciones contradictorias.

## I.7 Restricciones

Solo teléfono como hardware del usuario; servicios externos gratuitos o autoalojables; conectividad variable; límites de fuentes cartográficas.

## I.8 Supuestos

Teléfono de pruebas disponible; datos/mapas con términos compatibles; acceso a participantes voluntarios para validación supervisada.

## I.9 Resultados esperados

APK instalable; módulos MVP verificados; rutas y reportes; pruebas y evidencias. No presentar resultados futuros como ya obtenidos.

## I.10 Metodología de implementación

Iterativa con incrementos y criterios de aceptación definidos en FD03.

## I.11 Actores claves

Persona usuaria, contacto de confianza, desarrolladores, docente/evaluador, eventualmente moderador.

## I.12 Papel y responsabilidades

Roles personales y aprobaciones: [POR DEFINIR].

## I.13 Plan de monitoreo y evaluación

Matriz de trazabilidad, pruebas por RF, métricas de IA, batería, offline, accesibilidad, riesgos y revisiones de documento.

## I.14 Cronograma

Fases: documentación, MVP cámara/OCR, voz, ubicación/mapas, reportes/sincronización, pruebas y defensa. Fechas: [POR DEFINIR].

## I.15 Hitos de entregables

H1 FD01/FD02/FD06 aprobados; H2 FD03; H3 FD04; H4 MVP; H5 integración; H6 FD05.

## II. Presupuesto

1. Planteamiento de aplicación. 2. Cuadro de presupuesto. 3. Factibilidad enlazada FD01. 4. Evaluación financiera, solo con cifras verificables.

## Anexo 01

Requerimientos del sistema: referencia FD03; conservar identidad de versiones.

---

**Nota de conformidad:** El archivo oficial editable en Word deberá conservar portada, logos, tablas e índices exigidos por la plantilla docente. Este Markdown es la fuente de trabajo coordinada, no reemplaza la entrega DOCX.
