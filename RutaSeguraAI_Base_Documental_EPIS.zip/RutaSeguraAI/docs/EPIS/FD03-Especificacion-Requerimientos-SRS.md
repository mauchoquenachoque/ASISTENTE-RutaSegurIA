# FD03 — Especificación de Requerimientos de Software (SRS)

> **Proyecto:** Ruta Segura AI PRO  
> **Institución:** Universidad Privada de Tacna — EPIS  
> **Estado:** Borrador técnico inicial; no es documento aprobado  
> **Versión:** 0.1.0 | **Fecha:** 2026-11-20  
> **Curso / docente / integrantes:** [PENDIENTE DE COMPLETAR]  
> **Normativa:** Secciones adaptadas de los archivos FD01–FD06 proporcionados.  
> **Control documental:** Ver `docs/EPIS/00-GOBERNANZA-Y-TRAZABILIDAD.md`.

## Control de versiones

| Versión | Fecha | Autor | Revisó | Aprobó | Cambio |
|---|---|---|---|---|---|
| 0.1.0 | 2026-11-20 | [Por definir] | Pendiente | Pendiente | Base documental inicial |

## Introducción

Este FD03 utiliza la organización del ejemplo aportado por el usuario, que pertenece a otro sistema. No reutilizar sus estadísticas, institución ficticia, equipo, bibliografía ni resultados.

## I. Generalidades de la organización

Proyecto académico Ruta Segura AI. Organización promotora, roles, visión, misión y organigrama: [POR CONFIRMAR]. No inventar entidad cliente.

## II. Visionamiento

Descripción de problema, objetivos de negocio y diseño, alcance, viabilidad y levantamiento de información. Evidencia de entrevistas/encuestas: [PENDIENTE].

## III. Análisis de procesos

Diagramar proceso actual de consulta manual de entorno/lectura y proceso propuesto con asistencia móvil; validar con personas usuarias.

## IV.a Cuadro de requerimientos funcionales inicial

RF-01 detectar objetos en cámara; RF-02 OCR local; RF-03 alertas por voz/vibración; RF-04 consultar ubicación; RF-05 consultar/guardar rutas; RF-06 reportar barreras; RF-07 activar flujo SOS; RF-08 sincronizar cola offline; RF-09 configurar accesibilidad; RF-10 consultar historial.

## IV.b Requerimientos no funcionales

RNF-01 compatibilidad TalkBack; RNF-02 uso offline para funciones esenciales; RNF-03 consentimiento explícito para ubicación compartida; RNF-04 avisos de incertidumbre; RNF-05 manejo seguro de claves y datos; RNF-06 mediciones de latencia y batería sobre dispositivo real; RNF-07 manejo de permisos y recuperación de fallos.

## IV.c Requerimientos funcionales finales y aceptación

RF-01: dada cámara habilitada y un objeto de clase soportada, muestra etiqueta y posición con confianza; aceptar según pruebas y dataset definidos. RF-02: con texto legible, muestra resultado OCR y habilita TTS. RF-08: reporte creado offline queda pendiente y se sincroniza de manera idempotente al recuperar conexión. Completar criterios para cada RF antes de desarrollo.

## IV.d Reglas de negocio

RN-01 nunca afirmar ruta segura; RN-02 no compartir coordenadas sin acción informada; RN-03 reportes pendientes no se publican sin conexión; RN-04 un resultado de IA de baja confianza no produce un aviso categórico; RN-05 SOS requiere confirmación accesible salvo decisión futura formal y validada.

## V. Fase de desarrollo

Perfiles de usuario, modelos conceptual/lógico, paquetes, casos de uso CU-01 a CU-10, narrativas, diagramas de actividades, secuencia y clases. Trazabilidad: CU-01→RF-01, CU-02→RF-02, etc.

## Conclusiones, recomendaciones y fuentes

Completar con resultados reales y fuentes bibliográficas pertinentes, sin copiar el contenido del ejemplo de otro proyecto.

---

**Nota de conformidad:** El archivo oficial editable en Word deberá conservar portada, logos, tablas e índices exigidos por la plantilla docente. Este Markdown es la fuente de trabajo coordinada, no reemplaza la entrega DOCX.
